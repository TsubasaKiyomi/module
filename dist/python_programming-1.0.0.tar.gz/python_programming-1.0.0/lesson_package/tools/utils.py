# 引数のwordを！付きで２回表示させる。
def say_twice(word):
    return(word + '!') * 2
