from lesson_package.tools import utils
# from ..tools import utils


def sing():
    return 'tekito'


def cry():
    return utils.say_twice('tekitouuuu')
